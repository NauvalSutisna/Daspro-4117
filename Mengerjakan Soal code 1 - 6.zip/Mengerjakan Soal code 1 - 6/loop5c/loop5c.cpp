#include <iostream>

using namespace std;

int main()
{
    cout << "Program inputan -99" << endl;
    int i;
    while(i != -99){
        cout << "input bilangan anda : ";
        cin >> i;
    }
    return 0;
}
