#include <iostream>
#include <vector>

using namespace std;

int main()
{
    cout << "Program membuat maximum dan minimum" << endl;
    vector<int> num = {};
    int min = 0;
    int max = 0;

    int i;
    while(i != -99){
        cout << "input bilangan anda : ";
        cin >> i;
        num.push_back(i);
    }

    if(num.size() > 0){
        min = num[0];
        max = num[0];

        for(int x = 1; x < num.size() - 1; x++){
            if(min > num[x]){
                min = num[x];
            }
            else if (max < num[x]){
                     max = num[x];
            }
        }
    }
    cout << "minimum = " << min << endl;
    cout << "maximum = " << max << endl;
    return 0;
}
