#include <iostream>

using namespace std;

int main()
{
    cout << "Program mencetak angka dari 100 hingga 1 menggunakan looping for multi expression" << endl;
    int j = 1;
    for(int i = 100; i >= 1; i--){
        cout << "i= " << i << " dan j= " << j << endl;
        j++;
    }
    return 0;
}
