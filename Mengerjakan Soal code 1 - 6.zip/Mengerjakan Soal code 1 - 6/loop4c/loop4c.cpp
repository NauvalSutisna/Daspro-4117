#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    cout << "Program mencetak rata-rata angka dari 1 hingga 20 menggunakan loop for" << endl;
    int i,hasil;
    float rata;
    for(int i = 1; i <= 20; i++){
        hasil = hasil + i;
        rata = hasil / i;
        cout << i << endl;
    }
    cout << "Hasil = " << hasil << endl;
    cout << "Rata - Rata= " << rata << endl;
    return 0;
}
