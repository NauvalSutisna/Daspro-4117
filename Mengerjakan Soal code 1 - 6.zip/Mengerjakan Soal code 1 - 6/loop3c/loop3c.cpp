#include <iostream>

using namespace std;

int main()
{
    cout << "Program mencetak angka dari 100 hingga 1 menggunakan loop for dan akan berhenti(break) dianngka 55" << endl;
    for(int i = 100; i >= 1; i--){
        if(i == 54){
            break;
        }
        cout << "i = " << i << endl;
    }
    return 0;
}
