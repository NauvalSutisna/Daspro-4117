#include <iostream>

using namespace std;

int main()
{
    cout << "Program mencetak angka dari 100 hingga 1 tetapi hanya yang genap saja menggunakan statement continue" << endl;
    for(int i = 100; i >= 1; i--){
        if(i % 2 == 1){
            continue;
        }
        cout << "Output Nilai Genap dari 100 sd 1 = " << i << endl;
    }
    return 0;
}
